import { useState } from "react";
import "./App.css";
import { v4 as uuidv4 } from "uuid";

function App() {
  const [todos, setTodos] = useState([
    { id: uuidv4(), text: "Buy milk", isCompleted: false },
    { id: uuidv4(), text: "Do laundry", isCompleted: false },
    { id: uuidv4(), text: "Finish project", isCompleted: true },
  ]);
  const [whichForm, setWhichForm] = useState("add");
  const [todoToUpdate, setTodoToUpdate] = useState({
    id: "",
    text: "",
    isCompleted: false,
  });

  function addTodo(todoText) {
    const newTodo = { id: uuidv4(), text: todoText, isCompleted: false };
    setTodos([...todos, newTodo]);
  }

  function deleteTodo(todoId) {
    setTodos(todos.filter((todo) => todo.id !== todoId));
  }

  function updateTodo() {
    const newTodos = [...todos];
    const todoIndex = newTodos.findIndex(
      (todo) => todo.id === todoToUpdate.id
    );
    if (todoIndex >= 0) {
      newTodos[todoIndex] = todoToUpdate;
      setTodos(newTodos);
      setWhichForm("add");
      setTodoToUpdate({ id: "", text: "", isCompleted: false });
    }
  }

  return (
    <div className="App">
      <h2>Todo List</h2>
      {todos.map((todo) => (
        <Todo
          key={todo.id}
          id={todo.id}
          text={todo.text}
          isCompleted={todo.isCompleted}
          deleteTodo={deleteTodo}
          setWhichForm={setWhichForm}
          setTodoToUpdate={setTodoToUpdate}
        />
      ))}
      {whichForm === "add" && <TodoForm addTodo={addTodo} />}
      {whichForm === "update" && (
        <TodoForm
          addTodo={addTodo}
          todoToUpdate={todoToUpdate}
          setWhichForm={setWhichForm}
          setTodoToUpdate={setTodoToUpdate}
          updateTodo={updateTodo}
        />
      )}
    </div>
  );
}

function Todo({
  id,
  text,
  isCompleted,
  deleteTodo,
  setWhichForm,
  setTodoToUpdate,
}) {
  function handleDelete() {
    deleteTodo(id);
  }

  function handleUpdate() {
    setWhichForm("update");
    setTodoToUpdate({ id, text, isCompleted });
  }

  return (
    <div className="todo">
      <p>{text}</p>
      <div className="buttons">
        <button onClick={handleDelete}>Delete</button>
        <button onClick={handleUpdate}>Update</button>
      </div>
    </div>
  );
}