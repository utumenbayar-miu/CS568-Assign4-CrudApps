import { useEffect, useState } from "react";
import "./App.css";
import { v4 as uuidv4 } from "uuid";

function App() {
  const [students, setStudents] = useState([
    { id: 1234, name: "s1", age: 12 },
    { id: 12, name: "s2", age: 10 },
    { id: 32, name: "s3", age: 11 },
  ]);
  const [whichForm, setWhichForm] = useState("add");
  const [studentToUpdate, setStudentToUpdate] = useState({ name: "", age: 0 });

  function addStudent(student) {
    const newStudents = [...students];
    newStudents.unshift(student);
    setStudents(newStudents);
  }

  function updateStudent(student) {
    const newStudents = [...students];

    for (let s of newStudents) {
      if (s.id === student.id) {
        s.name = student.name;
        s.age = student.age;
        break;
      }
    }

    setStudents(newStudents);
  }

  function deleteStudent(studentId) {
    setStudents(students.filter((s) => (s.id !== studentId ? s : null)));
  }

  return (
    <div className="App">
      <h2>Student List</h2>
      {students.map((s) => (
        <Student
          key={s.id}
          id={s.id}
          name={s.name}
          age={s.age}
          deleteStudent={deleteStudent}
          setWhichForm={setWhichForm}
          setStudentToUpdate={setStudentToUpdate}
        />
      ))}
      <StudentForm
        addStudent={addStudent}
        whichForm={whichForm}
        studentToUpdate={studentToUpdate}
        updateStudent={updateStudent}
        setWhichForm={setWhichForm}
      />
    </div>
  );
}

function Student(props) {
  return (
    <div>
      <h3>{props.name}</h3>
      <p>{props.age}</p>
      <button onClick={() => props.deleteStudent(props.id)}>Delete</button>
      <button onClick={() => {
        props.setStudentToUpdate({ id: props.id, name: props.name, age: props.age });
        props.setWhichForm("update");
      }}>
        Update
      </button>
      <hr />
    </div>
  );
}

function StudentForm(props) {
  const [name, setName] = useState("");
  const [age, setAge] = useState(0);

  useEffect(() => {
    if (props.whichForm === "update") {
      setName(props.studentToUpdate.name);
      setAge(props.studentToUpdate.age);
    } else {
      setName("");
      setAge(0);
    }
  }, [props.whichForm, props.studentToUpdate]);

  function handleSubmit(e) {
    e.preventDefault();

    if (props.whichForm === "add") {
      const student = {
        id: uuidv4(),
        name,
        age,
      };
      props.addStudent(student);
    } else {
      const student = {
        id: props.studentToUpdate.id,
        name,
        age,
      };
      props.updateStudent(student);
      props.setWhichForm("add");
    }

    setName("");
    setAge(0);
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>{props.whichForm === "add" ? "Add Student" : "Update Student"}</h2>
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target)}
        />
<input
type="number"
placeholder="Age"
value={age}
onChange={(e) => setAge(parseInt(e.target.value))}
/>
<button type="submit">
{props.whichForm === "add" ? "Add" : "Update"}
</button>
{props.whichForm === "update" && (
<button onClick={() => props.setWhichForm("add")}>Cancel</button>
)}
</form>
);
}

export default App;